namaPrajurit = {'Vincent' 'Desta' 'Enzy' 'Hesti' 'Marshel' 'Tretan' 'Dustin' 'Coki'};
data = [ 12  8  80
         10  3  50
         7   5  95
         10  5  75
         11  8  87
         10  8  100
         7   4  30
         12  10 60];
%Batas kriteria
maksJarak = 100;
maksJumlahTembakan = 12;
maksTepatTarget = 12;

%Normalisasi
data(:,1) = data(:,1) / maksJumlahTembakan;
data(:,2) = data(:,2) / maksTepatTarget;
data(:,3) = data(:,3) / maksJarak;

relasiAntarKriteria = [ 1 4 4
                        0 1 1
                        0 0 1];

TFN = {[-100/3 0     100/3] [3/100 0     -3/100]
       [0      100/3 200/3] [3/200 3/100 0     ]
       [100/3  200/3 300/3] [3/300 3/200 3/100 ]
       [200/3  300/3 400/3] [3/400 3/300 3/200 ]};

[RasioKonsistensi] = HitungKonsistensiAHP(relasiAntarKriteria);

if RasioKonsistensi < 0.10
    % Metode Fuzzy AHP
    [bobotAntarKriteria, relasiAntarKriteria] = FuzzyAHP(relasiAntarKriteria, TFN); 
    % Hitung nilai skor akhir 
    ahp = data * bobotAntarKriteria'; 
    
    disp('+=================================================+')
    disp('|    Hasil Perhitungan dengan metode Fuzzy AHP    |')
    disp('+=================================================+')
    disp('Nama Prajurit  Skor Akhir        Kesimpulan        ')
end

for i = 1:size(ahp, 1)
    if ahp(i) < 0.5
        status = 'Tembakan tidak akurat';
    elseif ahp(i) < 0.6
        status = 'Tembakan kurang akurat';
    elseif ahp(i) < 0.7
        status = 'Tembakan cukup akurat';
    elseif ahp(i) < 0.8
        status = 'Tembakan akurat';
    else
        status = 'Tembakan sangat akurat';
    end
 
    disp([char(namaPrajurit(i)), blanks(13 - cellfun('length',namaPrajurit(i))), '  ', ...
        num2str(ahp(i)), blanks(10 - length(num2str(ahp(i)))), '  ', ...
        char(status)])
end